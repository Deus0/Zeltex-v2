﻿using UnityEngine;
using System.Collections;

public static class GameSettings {
	public static bool IsSpeechSound = false;
	public static float SpeedSpeed = 0.02f;
}
