﻿using UnityEngine;
using System.Collections;

// Utility download

public class CameraMovement : MonoBehaviour 
{
	public float mainSpeed = 20.0f; //regular speed
	//private float shiftAdd = 250.0f; //multiplied by how long shift is held.  Basically running
	private float maxShift = 1000.0f; //Maximum speed when holdin gshift
	private float camSens = 0.2f; //How sensitive it with mouse
	private Vector3 lastMouse = new Vector3(255, 255, 255); //kind of in the middle of the screen, rather than at the top (play)
	private float totalRun = 1.0f;


	void OnEnable() 
	{
		if (GetComponent<CharacterSystem.MouseLocker> ()) {
			GetComponent<CharacterSystem.MouseLocker> ().SetMouse(false);
		}
	}
	void Update ()
	{
		
		if (Input.GetMouseButtonDown (1)) 
		{
			lastMouse = Input.mousePosition;
		}
		if (Input.GetMouseButton (1)) 	// when holding down right click
		{
			lastMouse = Input.mousePosition - lastMouse;
			lastMouse = new Vector3 (-lastMouse.y * camSens, lastMouse.x * camSens, 0);
			lastMouse = new Vector3 (transform.eulerAngles.x + lastMouse.x, transform.eulerAngles.y + lastMouse.y, 0);
			transform.eulerAngles = lastMouse;
			lastMouse = Input.mousePosition;
			//Mouse  camera angle done.  
		
			//Keyboard commands
			float f = 0.0f;
			var BaseInput = GetBaseInput ();
			if (Input.GetKey (KeyCode.LeftShift)) 
			{
				BaseInput = BaseInput * mainSpeed*2f;
				//totalRun += Time.deltaTime;
				/*BaseInput = BaseInput * totalRun * shiftAdd;
				BaseInput.x = Mathf.Clamp (BaseInput.x, -maxShift, maxShift);
				BaseInput.y = Mathf.Clamp (BaseInput.y, -maxShift, maxShift);
				BaseInput.z = Mathf.Clamp (BaseInput.z, -maxShift, maxShift);*/
			} else {
				//totalRun = Mathf.Clamp (totalRun * 0.5f, 1, 1000);
				BaseInput = BaseInput * mainSpeed;
			}
			if (Input.GetKey (KeyCode.E)) 
			{
				BaseInput.y += mainSpeed;
			}
			else if (Input.GetKey (KeyCode.Q)) 
			{
				BaseInput.y -= mainSpeed;
			}
		
			BaseInput = BaseInput * Time.deltaTime;
			if (Input.GetKey (KeyCode.Space)) 
			{ //If player wants to move on X and Z axis only
				f = transform.position.y;
				transform.Translate (BaseInput);
				transform.position = new Vector3 (transform.position.x, f, transform.position.z);
			} else {
				transform.Translate (BaseInput);
			}
		}
	}
	
	private Vector3 GetBaseInput() { //returns the basic values, if it's 0 than it's not active.
		Vector3 MyInput = new Vector3();
		if (Input.GetKey (KeyCode.W)){
			MyInput += new Vector3(0, 0 , 1);
		}
		if (Input.GetKey (KeyCode.S)){
			MyInput += new Vector3(0, 0 , -1);
		}
		if (Input.GetKey (KeyCode.A)){
			MyInput += new Vector3(-1, 0 , 0);
		}
		if (Input.GetKey (KeyCode.D)){
			MyInput += new Vector3(1, 0 , 0);
		}
		float MouseScroll = Input.GetAxis("Mouse ScrollWheel");
		if (MouseScroll > 0) {
			MyInput += new Vector3(0, 0 , 10);
		} else if (MouseScroll < 0) {
			MyInput += new Vector3(0, 0 , -10);
		}
		return MyInput;
	}

}
