﻿using UnityEngine;
using System.Collections;
using UnityEngine.Events;

public class OnDisableEventHandler : MonoBehaviour 
{
	public UnityEvent OnDisableEvent;

	void OnDisable() 
	{
		OnDisableEvent.Invoke ();
	}
}
